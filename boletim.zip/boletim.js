// Gera um número aleatório entre 0.0 e 10.0 com até 1 casa decimal.
function geraNota() {
    let valor = Math.floor(Math.random() * 101);
    return valor / 10;
}
function aumentar_nota(e) {
    let valormedia = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.innerText)
    let valor3 = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.innerText)
    let valor2 = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.innerText)
    let valor1 = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.innerText)
    let media = e.parentElement.previousElementSibling.previousElementSibling
    let nota1 = e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling
    let nota2 = e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling
    let nota3 = e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling

    if (valor1 <= 9.5 && valor2 <= 9.5 && valor3 <= 9.5) {
        console.log(valor3)
        nota1.innerText = valor1 + 0.5
        nota2.innerText = valor2 + 0.5
        nota3.innerText = valor3 + 0.5
        media.innerText = valormedia + 0.5
    } else {
        alert("impossivel aumentar nota alem de 10")

    }

}
function diminuir_nota(e) {
    let vm = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.innerText)
    let v3 = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.innerText)
    let v2 = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.innerText)
    let v1 = parseFloat(e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.innerText)
    let nm = e.parentElement.previousElementSibling.previousElementSibling
    let n1 = e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling
    let n2 = e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling
    let n3 = e.parentElement.previousElementSibling.previousElementSibling.previousElementSibling
    console.log("reduzir")
    if (v1 >= 0.5 && v2 >= 0.5 && v3 >= 0.5) {
        n1.innerText = v1 - 0.5
        n2.innerText = v2 - 0.5
        n3.innerText = v3 - 0.5
        nm.innerText = vm - 0.5

    }
    else {
        alert("impossivel reduzir nota alem de 0")
    }


}
function remove_aluno(e) {
    e.parentElement.parentElement.remove()

}
function remove_pior() {
    let alunos=document.querySelectorAll("tr")
    if(alunos.length!=0){
        let pior_media=alunos[0].children[4].innerText
        let pior_aluno=0
        for(i=0;i<alunos.length;i++){
            if(parseFloat(alunos[i].children[4].innerText)<parseFloat(pior_media)){
                pior_aluno=i

            }
        }
        alunos[pior_aluno].remove()

    }
    else{
        alert("não há alunos")
    }
    
    



}
let remover_pior = document.querySelector(".is-danger")
remover_pior.addEventListener("click", function () {
    remove_pior()
})


let adicionar_aluno = document.querySelector(".is-primary")
adicionar_aluno.addEventListener("click", function () {
    let campo = document.querySelector("input")
    if (campo.value == "") {
        alert("campo de inserir está vazio")
    }
    else {
        let corpo = document.querySelector("tbody")
        let nova_linha = document.createElement("tr")
        let nome = document.querySelector("input")
        let col_nome = document.createElement("td")
        col_nome.innerText = nome.value

        let nota1 = document.createElement("td")
        let valor1 = geraNota()
        nota1.innerText = valor1

        let nota2 = document.createElement("td")
        let valor2 = geraNota()
        nota2.innerText = valor2

        let nota3 = document.createElement("td")
        let valor3 = geraNota()
        nota3.innerText = valor3
        let media = document.createElement("td")
        valor_media = ((valor1 + valor2 + valor3) / 3).toFixed(1)
        media.innerText = valor_media


        corpo.append(nova_linha)
        nova_linha.append(col_nome)
        nova_linha.append(nota1)
        nova_linha.append(nota2)
        nova_linha.append(nota3)
        nova_linha.append(media)
        let status = document.createElement("td")
        if (valor_media < 4) {

            status.innerText = "Reprovado"

        } else {
            if (valor_media < 6) {
                status.innerText = "Recuperação"

            } else {
                status.innerText = "Aprovado"
            }
        }
        nova_linha.append(status)
        let botões = document.createElement("td")
        let remover = document.createElement("button")
        remover.innerText = "Remover"
        let aumentar = document.createElement("button")
        aumentar.innerText = "Aumentar nota"
        let diminuir = document.createElement("button")
        diminuir.innerText = "Diminuir nota"

        aumentar.classList.add("button")
        aumentar.classList.add("is-primary")
        aumentar.classList.add("plus")
        remover.classList.add("button")
        remover.classList.add("is-warning")
        remover.classList.add("rem")
        diminuir.classList.add("button")
        diminuir.classList.add("is-info")
        diminuir.classList.add("minus")

        botões.append(aumentar)
        botões.append(diminuir)
        botões.append(remover)
        nova_linha.append(botões)
        aumentar.addEventListener("click", function () {
            aumentar_nota(aumentar)
        })
        remover.addEventListener("click", function () {
            remove_aluno(remover)
        })
        diminuir.addEventListener("click", function () {
            diminuir_nota(diminuir)
        })
    }


})
let aumentadores = document.querySelectorAll(".plus")
for (let elementos of aumentadores) {
    elementos.addEventListener("click", function () { aumentar_nota(elementos) })
}
let reduzir_nota = document.querySelectorAll(".minus")
for (let elements of reduzir_nota) {
    elements.addEventListener("click", function () {
        diminuir_nota(elements)
    })
}
let remover_aluno = document.querySelectorAll(".rem")
for (let elementos of remover_aluno) {
    elementos.addEventListener("click", function () {
        remove_aluno(elementos)

    })
}